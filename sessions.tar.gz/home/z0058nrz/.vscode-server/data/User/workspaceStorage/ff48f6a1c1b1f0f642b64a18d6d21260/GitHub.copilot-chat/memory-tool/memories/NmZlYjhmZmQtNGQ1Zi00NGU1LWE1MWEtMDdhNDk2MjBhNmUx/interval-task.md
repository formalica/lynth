# Interval arithmetic task (lynth)
Decisions (user answers):
- Trust: implement BOTH kernel-only and kernel+native (native_decide) modes, chosen by lynth config param.
  native_decide in Lean 4.34 adds per-decl axiom `<decl>._native.native_decide.ax_1_1`.
- Fix broken tests minimally; change MP31 hypergeometric to convergent point |z|<1.
- Meta: adaptive (Nat.find + convergence) by default; piecewise poly when bounded+tame.
- Scope: phases 1-7 in full detail; from 8/9 only complex boxes; complex support everywhere is VERY important.
- Time budget <= 60 s per declaration.
- LeanCert: selective vendoring (option B) into Lynth/Interval/Vendor, keep Apache headers.
- Local git commits at milestones OK (no push).
Kernel perf: ~4000 Taylor-steps/s (200-bit ints) via decide +kernel.
Spec location: docs/interval/*.md
Kernel perf facts: structural recursion (brecOn) ~50us/step; rounding op ~1ms; Nat.log2 is NOT
accelerated (WF-ish Nat.rec per bit) -> use Nat.rec binary search + @[csimp] (Vendor natBitLength).
Tests pin axioms => kernel proofs required (no native). Use `set_option Elab.async false` to time.
Status (commit 0fd0187): Basic 6/6, Compositions 24/36 (rest = deferred specials), Sums 5/7.
Next: infinite sums (AIA, docs 08), integrals (07), meta (09), discrete, complex fns/tests.
2026-10-01: uncommitted series work builds; InfiniteSums.lean run blew up to 14GB RSS (killed).
Machine: 15GB RAM, 14 cores -> max 3 parallel lean jobs. Launched 3 parallel subagents:
 A series (owns Series/*, Goals/Series.lean, Core/Asy*), B integrals (Check/Integral, Goals/Integral),
 C box+discrete (Check/Box, Goals/Box, Goals/Discrete). Procedure.lean wiring done by me afterwards.
