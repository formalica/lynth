# Lynth Meta Pipeline Audit — Key Findings

## Critical Gaps from Planned Architecture

### 1. Dispatch Mechanism: Sequential if/else, NOT Discrimination Tree
**Plan**: "One discrimination-tree registry of problem shapes"
**Reality**: Sequential try-chain in `matchFrag` (Sat/Compile.lean:1806-1809)
```lean
def matchFrag (P : Expr) : MetaM (Option (List Frag)) := do
  match ← matchFrag1D P with       // TRY 1D FIRST
  | some frags => pure (some frags)
  | none => matchFragNested P       // FALL BACK TO NESTED
```

### 2. Hardcoded Sizes for 2D Boards
**Plan**: "Generic over all puzzles"
**Reality**: lin2D/unlin2D (Sat/Compile.lean:572-576) HARDCODED TO Fin 9 × Fin 81
- mkRCGuardLam creates guards for Fin 81 only
- All nested functions use literal 81 and 9
- **Consequences**: Only 9×9 Sudoku works for 2D; can't generalize to arbitrary n×n

### 3. Fragment Matcher Limitations
- KnightsTourArbitrary only works as 1D (Fin n → Fin k)
- ThreeColoring is fixed at Fin 8 (line 50, Test/FinDomain/Meta/ThreeColoring.lean)
- LightsOutArbitrary is 1D, symbolic evaluation of applyAll via foldl over finRange

## Axioms & Termination
- `cdcl_correct` (Sat/Verified.lean:37): Soundness + completeness for one solver run
- `cdcl_fuel_suffices` (Sat/Verified.lean:55): Existence of doubling level that decides all inputs
- Termination: cdclLoop with geometric doubling (2^k restarts), found via Nat.find in solveTotal
- Fuel constants: compileFuel = 2,000,000, compileRestart = 100 (Sat/Compile.lean:1637-1638)
