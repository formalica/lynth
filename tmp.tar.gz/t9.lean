import Lynth
open Lynth.Interval
set_option Elab.async false
set_option profiler true
set_option profiler.threshold 1
def r0 : Nat → Bool | 0 => true | n+1 => ((12345678901234567 + n) != 0) && r0 n
def r1 : Nat → Bool | 0 => true | n+1 => (((12345678901234567 + n) >>> 30) != 0) && r1 n
def r2 : Nat → Bool | 0 => true | n+1 => ((Nat.shiftRight (Nat.add 12345678901234567 n) 30).beq 0) && r2 n
def r3 : Nat → Bool | 0 => true | n+1 => ((Nat.shiftRight (Nat.add 12345678901234567 n) 30).beq 0) && ((Nat.shiftRight (Nat.add 12345678901234567 n) 31).beq 0) && ((Nat.shiftRight (Nat.add 12345678901234567 n) 32).beq 0) && ((Nat.shiftRight (Nat.add 12345678901234567 n) 33).beq 0) && r3 n
def r4 : Nat → Bool | 0 => true | n+1 => (((12345678901234567 + n : Int) + (-5 : Int)) != 0) && r4 n
def r5 : Nat → Bool | 0 => true | n+1 => ((Int.add (Int.ofNat (Nat.add 12345678901234567 n)) (Int.negSucc 4)) != 0) && r5 n
def r6 : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.natBitLength (12345678901234567 + n) != 0) && r6 n
def r7 : Nat → Bool | 0 => true | n+1 => (Nat.log2 (12345678901234567 + n) != 0) && r7 n
theorem t0 : r0 1000 = true := by decide +kernel
theorem t1 : r1 1000 = true := by decide +kernel
theorem t2 : r2 1000 = false := by decide +kernel
theorem t3 : r3 1000 = false := by decide +kernel
theorem t4 : r4 1000 = true := by decide +kernel
theorem t5 : r5 1000 = true := by decide +kernel
theorem t6 : r6 1000 = true := by decide +kernel
theorem t7 : r7 1000 = true := by decide +kernel
