import Lynth
open Lynth.Interval
set_option Elab.async false
set_option profiler true
set_option profiler.threshold 1
def A (n : Nat) : Dy := ⟨12345678901234567 + n, -50⟩
def B (n : Nat) : Dy := ⟨98765432109876543 + n, -52⟩
def IA (n : Nat) : Ival := ⟨some (A n), some (A (n+1))⟩
def IB (n : Nat) : Ival := ⟨some (B n), some (B (n+1))⟩
def r0 : Nat → Bool | 0 => true | n+1 => ((A n).mantissa != 0) && r0 n
def r1 : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.bitLength (A n).mantissa != 0) && r1 n
def r2 : Nat → Bool | 0 => true | n+1 => ((Dy.addD 64 (A n) (B n)).mantissa != 0) && r2 n
def r3 : Nat → Bool | 0 => true | n+1 => ((Dy.mulD 64 (A n) (B n)).mantissa != 0) && r3 n
def r4 : Nat → Bool | 0 => true | n+1 => ((Dy.divD 64 (A n) (B n)).mantissa != 0) && r4 n
def r5 : Nat → Bool | 0 => true | n+1 => ((Ival.add 64 (IA n) (IB n)).isFinite) && r5 n
def r6 : Nat → Bool | 0 => true | n+1 => ((Ival.mul 64 (IA n) (IB n)).isFinite) && r6 n
def r7 : Nat → Bool | 0 => true | n+1 => ((Ival.div 64 (IA n) (IB n)).isFinite) && r7 n
def r8 : Nat → Bool | 0 => true | n+1 => ((Ival.ofRat 64 1).isFinite) && r8 n
def r9 : Nat → Bool | 0 => true | n+1 => ((NIval.pt n).toIval.isFinite) && r9 n
theorem t0 : r0 1000 = true := by decide +kernel
theorem t1 : r1 1000 = true := by decide +kernel
theorem t2 : r2 1000 = true := by decide +kernel
theorem t3 : r3 1000 = true := by decide +kernel
theorem t4 : r4 1000 = true := by decide +kernel
theorem t5 : r5 1000 = true := by decide +kernel
theorem t6 : r6 1000 = true := by decide +kernel
theorem t7 : r7 1000 = true := by decide +kernel
theorem t8 : r8 1000 = true := by decide +kernel
theorem t9 : r9 1000 = true := by decide +kernel
