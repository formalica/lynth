import Lynth
open Lynth.Interval
set_option profiler true
set_option profiler.threshold 20
def big : Dy := ⟨1219326311248285321112635269, -50⟩
def mBL : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.bitLength (1219326311248285321112635269 + n) != 0) && mBL n
def mSD : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.shiftDown ⟨1219326311248285321112635269 + n, -50⟩ 10).mantissa != 0 && mSD n
def mND : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.normalizeDown ⟨1219326311248285321112635269 + n, -50⟩ 64).mantissa != 0 && mND n
def mIA : Nat → Bool | 0 => true | n+1 => ((-50 : Int) + (n : Int) != 0) && mIA n
def mSR : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.shiftRightInt (1219326311248285321112635269 + n) 30 != 0) && mSR n
theorem t1 : mBL 1000 = true := by decide +kernel
theorem t2 : mSD 1000 = true := by decide +kernel
theorem t3 : mND 1000 = true := by decide +kernel
theorem t4 : mIA 1000 = true := by decide +kernel
theorem t5 : mSR 1000 = true := by decide +kernel
