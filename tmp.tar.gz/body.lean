
.

Arb ground truth: `arb/CERTIFICATES.md` (`arb/validate_lean_tests.py`, table
`arb/compositions.py`). -/
def cos_euler_add_sqrt : { x : Rat // abs (Real.cos (Real.eulerMascheroniConstant + Real.sqrt 2) - x) < Real.pi / 100 } := by lynth

/-- **MP19** — `sinh_bell_over_hundred`: `sinh, Nat.bell` composed in one expression, evaluated at
