import Lynth
set_option profiler true
set_option profiler.threshold 20

def bsS (n : Nat) : Nat → Nat → Nat → Nat
  | 0, _, hi => hi
  | fuel + 1, lo, hi =>
    if hi ≤ lo + 1 then hi
    else if n >>> ((lo + hi) / 2) == 0 then bsS n fuel lo ((lo + hi) / 2) else bsS n fuel ((lo + hi) / 2) hi

noncomputable def bsA (n : Nat) (fuel : Nat) : Nat → Nat → Nat :=
  fuel.rec (motive := fun _ => Nat → Nat → Nat) (fun _ hi => hi)
    (fun _ ih lo hi => (hi.ble (lo + 1)).rec
      (((n >>> ((lo + hi) / 2)).beq 0).rec (ih ((lo + hi) / 2) hi) (ih lo ((lo + hi) / 2))) hi)

@[csimp] theorem bsA_eq : @bsA = @bsS := by
  funext n fuel
  induction fuel with
  | zero => funext lo hi; rfl
  | succ k ih =>
    funext lo hi
    simp only [bsA, bsS] at ih ⊢
    rw [← ih]
    cases h1 : hi.ble (lo + 1) <;> cases h2 : (n >>> ((lo + hi) / 2)).beq 0 <;>
      simp_all [Nat.ble_eq, Nat.beq_eq] <;> rfl

def bl (n : Nat) : Nat := if n = 0 then 0 else bsA n 20 0 (if n >>> 256 == 0 then 256 else 65536)

#eval bl 1219326311248285321112635269
#eval Nat.log2 1219326311248285321112635269 + 1
def mBL : Nat → Bool | 0 => true | n+1 => (bl (1219326311248285321112635269 + n) != 0) && mBL n
def mLG : Nat → Bool | 0 => true | n+1 => (Nat.log2 (1219326311248285321112635269 + n) != 0) && mLG n
def mNone : Nat → Bool | 0 => true | n+1 => ((1219326311248285321112635269 + n) != 0) && mNone n
theorem t1 : mBL 1000 = true := by decide +kernel
theorem t2 : mLG 1000 = true := by decide +kernel
theorem t3 : mNone 1000 = true := by decide +kernel
