/-! Kernel performance experiment 2: many evaluations. -/

def fdiv2 (a : Int) (k : Nat) : Int := a >>> k

def expLoFix (x : Int) (p : Nat) : Nat → Int → Nat → Int
  | 0, _, _ => 0
  | fuel+1, t, k => t + expLoFix x p fuel ((fdiv2 (t * x) p) / (k+1 : Nat)) (k+1)

def expLo (x : Int) (p n : Nat) : Int := expLoFix x p n ((1 : Int) <<< p) 0

def sumMany : Nat → Int
  | 0 => 0
  | k+1 => expLo (((k : Int) + 1) <<< 120) 128 40 + sumMany k

set_option maxRecDepth 100000 in
theorem t1 : sumMany 1000 > 0 := by decide +kernel
