import Mathlib.Analysis.SpecialFunctions.Exp

structure Fn1 where
  name : String
  graph : ℝ → ℝ → Prop
  exu : ∀ x, ∃! y, graph x y
  ev : Nat → Nat

@[inline] def Fn1.ofFun (F : ℝ → ℝ) (name : String) (ev : Nat → Nat) : Fn1 :=
  { name, graph := fun x y => y = F x, exu := fun x => ⟨F x, rfl, fun _ h => h⟩, ev }

def expFn : Fn1 :=
  { name := "exp", graph := fun x y => y = Real.exp x, exu := fun x => ⟨Real.exp x, rfl, fun _ h => h⟩, ev := (· + 1) }

inductive E where
  | lit : Nat → E
  | app : Fn1 → E → E

def E.eval : E → Nat
  | .lit n => n
  | .app f a => f.ev a.eval

def myE : E := .app expFn (.app expFn (.lit 3))
#eval myE.eval
def f (x : Nat) : Nat := (E.app expFn (.lit x)).eval
#eval f 10
theorem t : myE.eval = 5 := by native_decide
theorem t2 : myE.eval = 5 := by decide +kernel
