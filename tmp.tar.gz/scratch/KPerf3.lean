import Mathlib.Data.Nat.Sqrt

def big : Nat := 2^4000 + 12345

set_option maxRecDepth 100000 in
theorem tlog : Nat.log2 big = 4000 := by decide +kernel

theorem tshift : (big >>> 3990) = 1024 := by decide +kernel

set_option maxRecDepth 100000 in
theorem tsqrt : Nat.sqrt (2^200) = 2^100 := by decide +kernel
