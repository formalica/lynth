theorem t : 2 + 2 = 4 := by native_decide
#print axioms t
