/-! Kernel performance experiment: fixed-point exp Taylor series. -/

/-- floor(a / 2^k) for Int a -/
def fdiv2 (a : Int) (k : Nat) : Int := a >>> k
/-- ceil(a / 2^k) -/
def cdiv2 (a : Int) (k : Nat) : Int := -((-a) >>> k)

/-- lower bound of exp(x/2^p) * 2^p, for 0 ≤ x, n terms, x scaled by 2^p -/
def expLoFix (x : Int) (p : Nat) : Nat → Int → Nat → Int
  | 0, _, _ => 0
  | fuel+1, t, k => t + expLoFix x p fuel ((fdiv2 (t * x) p) / (k+1 : Nat)) (k+1)

def expLo (x : Int) (p n : Nat) : Int := expLoFix x p n ((1 : Int) <<< p) 0

-- exp(1) with 200 bits precision and 80 terms
def e200 : Int := expLo ((1 : Int) <<< 200) 200 80

set_option maxRecDepth 100000 in
theorem t1 : e200 > 0 := by decide +kernel

set_option maxRecDepth 100000 in
theorem t2 : (e200 >>> 190) = 2783 := by decide +kernel

#eval e200 >>> 190
