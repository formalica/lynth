import Lynth.Interval.Num.CBox
open Lynth.Interval


#eval (Ival.ofRat 64 (1/3)).fmt
#eval (Ival.sqrt 64 (Ival.ofRat 64 2)).fmt
#eval (Ival.inv 64 (Ival.ofRat 64 3)).fmt
#eval (Ival.mul 64 (Ival.ofRat 64 (-3/2)) (Ival.ofRat 64 (7/5))).fmt
#eval (Ival.npow 64 (Ival.ofRat 64 (-3/2)) 5).fmt
#eval (Ival.sq 64 ⟨some (Dy.ofInt (-1)), some (Dy.ofInt 2)⟩).fmt
#eval (Ival.mul 64 ⟨some (Dy.ofInt 1), none⟩ ⟨some (Dy.ofInt 2), some (Dy.ofInt 3)⟩).fmt
#eval (CBox.norm 64 ⟨Ival.ofRat 64 3, Ival.ofRat 64 4⟩).fmt
theorem k1 : (Ival.ltB (Ival.sqrt 64 (Ival.ofRat 64 2)) (Ival.ofRat 64 (1415/1000))) = true := by decide +kernel
