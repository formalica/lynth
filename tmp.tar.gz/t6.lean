import Lynth
open Lynth.Interval
set_option profiler true
set_option profiler.threshold 20
theorem s1 : ((Expr.sum .real (.natLit 1000) (.c2 Fns.divR (.lit 1) (.c2 Fns.addR (.c1 Fns.natCastR (.var .nat 0)) (.lit 1)))).eval (Ctx.make 64) {}).isFinite = true := by decide +kernel
theorem s2 : ((Expr.sum .real (.natLit 1000) (.c2 Fns.divR (.lit 1) (.c2 Fns.npowR (.c2 Fns.addR (.c1 Fns.natCastR (.var .nat 0)) (.lit 1)) (.natLit 2)))).eval (Ctx.make 64) {}).isFinite = true := by decide +kernel
#eval Lynth.Interval.Vendor.Dyadic.bitLength 1219326311248285321112635269
#eval Nat.log2 1219326311248285321112635269 + 1
