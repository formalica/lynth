#!/bin/bash
# usage: runcap.sh FILE [TIMEOUT_S] [MAX_ANON_MB]  -- runs `lake env lean FILE` with a watchdog
F=$1; T=${2:-300}; MAXMB=${3:-4000}
cd /home/z0058nrz/lynth
start=$(date +%s)
lake env lean "$F" > /tmp/seriesA.log 2>&1 &
LP=$!
peak=0
while kill -0 $LP 2>/dev/null; do
  sleep 1
  pid=$(pgrep -f "^lean $F" | head -1)
  [ -z "$pid" ] && pid=$(pgrep -f "lean.*$F" | grep -v $LP | head -1)
  if [ -n "$pid" ]; then
    anon=$(awk '/RssAnon/{print int($2/1024)}' /proc/$pid/status 2>/dev/null)
    [ -n "$anon" ] && [ "$anon" -gt "$peak" ] && peak=$anon
    if [ -n "$anon" ] && [ "$anon" -gt "$MAXMB" ]; then
      echo "KILLED: anon RSS ${anon}MB > ${MAXMB}MB" >> /tmp/seriesA.log
      kill -9 $pid; kill $LP 2>/dev/null
    fi
  fi
  now=$(date +%s)
  if [ $((now - start)) -gt "$T" ]; then
    echo "KILLED: timeout ${T}s" >> /tmp/seriesA.log
    [ -n "$pid" ] && kill -9 $pid; kill $LP 2>/dev/null
  fi
done
echo "peak anon ${peak}MB, $(( $(date +%s) - start ))s" >> /tmp/seriesA.log
cat /tmp/seriesA.log | tail -${4:-40}
