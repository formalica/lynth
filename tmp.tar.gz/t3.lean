import Lynth
set_option profiler true
set_option profiler.threshold 500
theorem series_inv_sq_tail : abs ((∑ k ∈ Finset.range 1000, 1 / ((k : ℝ) + 1) ^ 2) - Real.pi ^ 2 / 6) < 1 / 500 := by lynth
theorem alternating_series_pi_over_four : abs ((∑ k ∈ Finset.range 100, (-1 : ℝ) ^ k / (2 * (k : ℝ) + 1)) - Real.pi / 4) < 1 / 100 := by lynth
