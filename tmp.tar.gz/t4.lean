import Lynth
open Lynth.Interval
set_option profiler true
set_option profiler.threshold 20
def manyLog : Nat → Bool | 0 => true | n+1 => (Nat.log2 (123456789012345 + n) != 0) && manyLog n
def manyMul : Nat → Bool | 0 => true | n+1 => (Vendor.Dyadic.mul ⟨12345678901, -20⟩ ⟨98765432101+n, -30⟩).mantissa != 0 && manyMul n
def manyMulD : Nat → Bool | 0 => true | n+1 => (Dy.mulD 64 ⟨12345678901, -20⟩ ⟨98765432101+n, -30⟩).mantissa != 0 && manyMulD n
def manyMulD' : Nat → Bool | 0 => true | n+1 => (Dy.mulD 64 ⟨1234567890123456789012345, -20⟩ ⟨98765432101234567890123+n, -30⟩).mantissa != 0 && manyMulD' n
def manyDivD : Nat → Bool | 0 => true | n+1 => (Dy.divD 64 ⟨12345678901, -20⟩ ⟨98765432101+n, -30⟩).mantissa != 0 && manyDivD n
def manyMin : Nat → Bool | 0 => true | n+1 => (Dy.min ⟨12345678901, -20⟩ ⟨98765432101+n, -30⟩).mantissa != 0 && manyMin n
def manyIsNonneg : Nat → Bool | 0 => true | n+1 => (Dy.isNonneg ⟨98765432101+n, -30⟩) && manyIsNonneg n
theorem t1 : manyLog 1000 = true := by decide +kernel
theorem t2 : manyMul 1000 = true := by decide +kernel
theorem t3 : manyMulD 1000 = true := by decide +kernel
theorem t3' : manyMulD' 1000 = true := by decide +kernel
theorem t4 : manyDivD 1000 = true := by decide +kernel
theorem t5 : manyMin 1000 = true := by decide +kernel
theorem t6 : manyIsNonneg 1000 = true := by decide +kernel
